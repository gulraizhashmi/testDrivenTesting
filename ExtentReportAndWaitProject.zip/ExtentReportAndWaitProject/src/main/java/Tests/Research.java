package Tests;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.im4java.core.CompareCmd;
import org.im4java.core.IMOperation;
import org.im4java.process.StandardStream;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import Utility.BaseClass;
import Utility.FrameWorkFunction;

public class Research extends BaseClass {
	public static FrameWorkFunction frameFunction;
	
	public static List<String> testCaseNameList;
	public static int sizeofList;
 @BeforeClass
 public void initialize() throws Throwable {
	 frameFunction=new FrameWorkFunction(driver);

 }
	@Test(priority=1)
	public static void verifyMainPage() throws Throwable {
		driver.get("https://nextbridge.com/");
		String pageSource = driver.getPageSource();
		//String contentNew=pageSource.replace("\\s", "");
		//contentNew=pageSource.replace("\\n", "");
		 // System.out.println(contentNew);
	//	Assert.assertTrue(pageSource.contains("Services"));
	//	System.out.println(pageSource);
		
		String filePath = System.getProperty("user.dir");
        //create a new file
        File file = new File(filePath + "\\" + "nextbridgecomhome.txt");
        System.out.print(filePath);
        try {
            if (!file.exists()) {
                file.createNewFile();
                System.out.println("File is created");
            } else {
                System.out.println("File already exist");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
		
		
		
		
		String TestFile =System.getProperty("user.dir")+ "\\nextbridgecomhome.txt";
		//  File FC = new File(TestFile);//Created object of java File class.
		//  FC.createNewFile();//Create file.
		  
		  //Writing In to file.
		  //Create Object of java FileWriter and BufferedWriter class.
	//	  FileWriter FW = new FileWriter(TestFile);
	//	  BufferedWriter BW = new BufferedWriter(FW);
	//	  BW.write(pageSource); //Writing In To File.
//		  BW.newLine();//To write next string on new line.
//		  BW.write("This Is Second Line."); //Writing In To File.
		//  BW.close();
		  
		  //Reading from file.
		  //Create Object of java FileReader and BufferedReader class.
		  FileReader FR = new FileReader(TestFile);
		  BufferedReader BR = new BufferedReader(FR);
		  String Content = "";
		  String Content1 = "";
		  //System.out.println(BR);
		  //Loop to read all lines one by one from file and print It.
		  String enter = System.getProperty("line.separator");
		  while((Content = BR.readLine())!= null){

			  Content1=Content1+Content+enter;  
		  }
		  //System.out.println(Content1);
		if(pageSource==Content1) {
			System.out.print("**********************");
		}
		
		//System.out.println(pageSource);
		System.out.println("***************************************************************");
		//System.out.println(Content1);
	}
	@Test(priority=2)
	public static void verifyMainPage1() throws Throwable {
		boolean compareSuccess = compareImages("src/main/images/p1.png","src/main/images/p2.png", "src/main/images/p3.gif");
		System.out.print(compareSuccess); 
		//(input1,input2,outputfile)
		//(boolean=true if same image...false if changes in image)
	}
		public static boolean compareImages (String data,String data1, String diff) {

		  CompareCmd compare = new CompareCmd();

		  // For metric-output
		  compare.setErrorConsumer(StandardStream.STDERR);
		  IMOperation cmpOp = new IMOperation();
		  // Set the compare metric
		  cmpOp.metric("mae");

		  // Add the expected image
		  cmpOp.addImage(data);

		  // Add the current image
		  cmpOp.addImage(data1);

		  // This stores the difference
		  cmpOp.addImage(diff);

		  try {
		    // Do the compare
		    compare.run(cmpOp);
		    return true;
		  }
		  catch (Exception ex) {
		    return false;
		  }
		}

	}

